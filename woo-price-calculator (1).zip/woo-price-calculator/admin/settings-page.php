<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Fetch current settings
$sizes = get_option('woo_price_calculator_sizes', '2x2,3x3,4x4');
$discounts = get_option('woo_price_calculator_discounts', '1-14:0,15-49:0.35,50-99:0.45,100-249:0.55,250+:0.65');

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['woo_price_calculator_save_settings'])) {
    // Verify nonce for security
    check_admin_referer('woo_price_calculator_save_settings');

    // Save settings
    update_option('woo_price_calculator_sizes', sanitize_text_field($_POST['sizes']));
    update_option('woo_price_calculator_discounts', sanitize_text_field($_POST['discounts']));
    
    // Redirect to avoid resubmission
    echo '<div class="updated"><p>' . esc_html__('Settings saved.', 'woo-price-calculator') . '</p></div>';
}
?>

<div class="wrap">
    <h1><?php esc_html_e('Price Calculator Settings', 'woo-price-calculator'); ?></h1>
    <form method="post" action="">
        <?php wp_nonce_field('woo_price_calculator_save_settings'); ?>
        
        <h2><?php esc_html_e('Size Options', 'woo-price-calculator'); ?></h2>
        <p><?php esc_html_e('Enter the sizes separated by commas (e.g., 2x2, 3x3, 4x4)', 'woo-price-calculator'); ?></p>
        <input type="text" name="sizes" value="<?php echo esc_attr($sizes); ?>" class="large-text" />

        <h2><?php esc_html_e('Discount Options', 'woo-price-calculator'); ?></h2>
        <p><?php esc_html_e('Enter discount ranges (e.g., 1-14:0, 15-49:0.35, 50-99:0.45, 100-249:0.55, 250+:0.65)', 'woo-price-calculator'); ?></p>
        <input type="text" name="discounts" value="<?php echo esc_attr($discounts); ?>" class="large-text" />
        
        <p class="submit">
            <input type="submit" name="woo_price_calculator_save_settings" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Changes', 'woo-price-calculator'); ?>">
        </p>
    </form>
</div>
