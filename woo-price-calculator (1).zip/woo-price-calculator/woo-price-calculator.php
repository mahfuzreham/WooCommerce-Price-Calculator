<?php
/**
 * Plugin Name: WooCommerce Price Calculator
 * Plugin URI: https://github.com/mahfuzreham/WooCommerce-Price-Calculator
 * Description: A WooCommerce plugin to dynamically calculate product prices based on size, quantity, and discounts.
 * Version: 1.0.0
 * Author: Md Mahfuz Reham
 * Author URI: https://github.com/mahfuzreham
 * Text Domain: woo-price-calculator
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Add plugin settings menu in WP dashboard
add_action('admin_menu', 'woo_price_calculator_add_settings_menu');
function woo_price_calculator_add_settings_menu() {
    add_menu_page(
        __('Price Calculator Settings', 'woo-price-calculator'), // Page title
        __('Price Calculator', 'woo-price-calculator'), // Menu title
        'manage_options', // Capability
        'woo-price-calculator-settings', // Menu slug
        'woo_price_calculator_settings_page', // Function to display settings page
        'dashicons-calculator', // Icon
        56 // Position
    );

    // Add a submenu page under the main menu item
    add_submenu_page(
        'woo-price-calculator-settings', // Parent slug
        __('Settings', 'woo-price-calculator'), // Page title
        __('Settings', 'woo-price-calculator'), // Menu title
        'manage_options', // Capability
        'woo-price-calculator-settings', // Menu slug
        'woo_price_calculator_settings_page' // Function to display settings page
    );
}

// Settings Page Function
function woo_price_calculator_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Handle form submission
    if (isset($_POST['woo_price_calculator_save_settings'])) {
        update_option('woo_price_calculator_sizes', sanitize_text_field($_POST['sizes']));
        update_option('woo_price_calculator_discounts', sanitize_text_field($_POST['discounts']));
        echo '<div class="notice notice-success is-dismissible"><p>Settings saved successfully!</p></div>';
    }

    // Load the settings page template
    include(plugin_dir_path(__FILE__) . 'admin/settings-page.php');
}

// Enqueue Admin CSS
add_action('admin_enqueue_scripts', 'woo_price_calculator_admin_styles');
function woo_price_calculator_admin_styles() {
    wp_enqueue_style('woo-price-calculator-admin', plugin_dir_url(__FILE__) . 'admin/settings.css');
}


// Localize script with settings
add_action('wp_enqueue_scripts', 'woo_price_calculator_localize');
function woo_price_calculator_localize() {
    $sizes = get_option('woo_price_calculator_sizes', '2x2,3x3,4x4');
    $discounts = get_option('woo_price_calculator_discounts', '1-14:0,15-49:0.35,50-99:0.45,100-249:0.55,250+:0.65');

    $price_data = array(
        'sizes' => explode(',', $sizes),
        'discounts' => array_map(function($range) {
            list($range_text, $discount) = explode(':', $range);
            $range_parts = explode('-', $range_text);
            return array(
                'min' => isset($range_parts[0]) ? (int)$range_parts[0] : 1,
                'max' => isset($range_parts[1]) ? (int)$range_parts[1] : 999999,
                'discount' => (float)$discount
            );
        }, explode(',', $discounts))
    );

    wp_localize_script('woo-price-calculator-js', 'priceCalculatorData', $price_data);
}
// Add size and quantity fields to the WooCommerce product page
add_action('woocommerce_before_add_to_cart_button', 'woo_price_calculator_display_fields');
function woo_price_calculator_display_fields() {
    $sizes = get_option('woo_price_calculator_sizes', '2x2,3x3,4x4');
    $sizes_array = explode(',', $sizes);

    echo '<div class="woo-price-calculator">';
    echo '<label for="size">' . __('Select Size:', 'woo-price-calculator') . '</label>';
    echo '<select id="size" name="size">';
    foreach ($sizes_array as $size) {
        echo '<option value="' . esc_attr($size) . '">' . esc_html($size) . '</option>';
    }
    echo '</select>';

    echo '<label for="quantity">' . __('Quantity:', 'woo-price-calculator') . '</label>';
    echo '<input type="number" id="quantity" name="quantity" value="1" min="1" />';

    echo '<p>' . __('Total Price:', 'woo-price-calculator') . ' <span id="total-price">0</span></p>';
    echo '</div>';
}
// Enqueue custom JavaScript for price calculation
add_action('wp_enqueue_scripts', 'woo_price_calculator_enqueue_scripts');
function woo_price_calculator_enqueue_scripts() {
    if (is_product()) { // Check if on a product page
        wp_enqueue_script('woo-price-calculator-js', plugin_dir_url(__FILE__) . 'assets/price-calculator.js', array('jquery'), '1.0.0', true);
    }
}
// Add to cart action to handle the custom price
add_action('woocommerce_add_to_cart', 'woo_price_calculator_add_to_cart', 10, 6);
function woo_price_calculator_add_to_cart($cart_item_key, $product_id, $quantity, $variation_id, $variations, $cart_item_data) {
    if (isset($_POST['size']) && isset($_POST['quantity'])) {
        $size = sanitize_text_field($_POST['size']);
        $quantity = intval($_POST['quantity']);
        
        // Example: Base price for demonstration (You can retrieve actual price logic)
        $basePrice = get_post_meta($product_id, '_price', true);
        $total_price = $basePrice * $quantity; // Calculate total price based on quantity

        // Save size and total price in cart item data
        $cart_item_data['size'] = $size;
        $cart_item_data['total_price'] = $total_price;
    }
    
    return $cart_item_data;
}
// Display custom data in the cart
add_filter('woocommerce_get_item_data', 'woo_price_calculator_display_cart_data', 10, 2);
function woo_price_calculator_display_cart_data($item_data, $cart_item) {
    if (isset($cart_item['size'])) {
        $item_data[] = array(
            'name' => __('Size', 'woo-price-calculator'),
            'value' => esc_html($cart_item['size']),
        );
    }

    if (isset($cart_item['total_price'])) {
        $item_data[] = array(
            'name' => __('Total Price', 'woo-price-calculator'),
            'value' => wc_price($cart_item['total_price']),
        );
    }

    return $item_data;
}
