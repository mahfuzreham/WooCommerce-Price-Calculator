jQuery(document).ready(function($) {
    function updateTotalPrice() {
        const size = $('#size').val();
        const quantity = parseInt($('#quantity').val(), 10);
        
        // Example base prices per size (you can customize these prices)
        let basePrice = 0;
        switch(size) {
            case '2x2':
                basePrice = 10; // Example price for 2x2 size
                break;
            case '3x3':
                basePrice = 15; // Example price for 3x3 size
                break;
            case '4x4':
                basePrice = 20; // Example price for 4x4 size
                break;
            default:
                basePrice = 0;
        }

        const totalPrice = basePrice * quantity; // Calculate total price
        $('#total-price').text(totalPrice); // Update total price display
    }

    // Event listeners for size and quantity changes
    $('#size, #quantity').on('change keyup', updateTotalPrice);
    updateTotalPrice(); // Initial calculation
});
